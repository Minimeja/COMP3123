# 100516804_COMP3123-exec05

How to run:
1) npm install
2) node index.js
3) Test with Postman:
   - GET /home
   - GET /profile
   - POST /login (valid + 2 invalid cases)
   - GET /logout/:username
